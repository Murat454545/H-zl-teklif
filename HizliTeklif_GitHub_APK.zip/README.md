# Hızlı Teklif

İnternetsiz çalışan, küçük işletmeler için hızlı teklif/PDF oluşturma Android uygulaması.

## GitHub'dan APK
1. Bu klasörü GitHub deposuna yükle.
2. **Actions → APK Olustur → Run workflow** seç.
3. İşlem bitince **Artifacts → HizliTeklif-APK** içinden APK'yı al.

Yerel komut:
`./gradle-8.9/bin/gradle assembleRelease`
