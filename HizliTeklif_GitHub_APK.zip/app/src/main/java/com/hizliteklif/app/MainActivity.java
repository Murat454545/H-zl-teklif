package com.hizliteklif.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText business, customer, product, qty, unit, note;
    TextView totalText;
    SharedPreferences prefs;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("data",0);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(14),dp(18),dp(14));
        root.setBackgroundColor(Color.WHITE);

        TextView title=new TextView(this);
        title.setText("HIZLI TEKLİF");
        title.setTextSize(25); title.setTextColor(Color.rgb(23,105,170));
        title.setTypeface(null,Typeface.BOLD);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(45)));

        business=field("İşletme / Ad Soyad",prefs.getString("business",""));
        customer=field("Müşteri", "");
        product=field("Ürün / Hizmet", "");
        qty=field("Miktar","1");
        unit=field("Birim fiyat (₺)","0");
        note=field("Not","");

        root.addView(business); root.addView(customer); root.addView(product);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(qty,new LinearLayout.LayoutParams(0,dp(60),1));
        row.addView(unit,new LinearLayout.LayoutParams(0,dp(60),2));
        root.addView(row);
        root.addView(note);

        totalText=new TextView(this); totalText.setTextSize(21); totalText.setTypeface(null,Typeface.BOLD);
        totalText.setPadding(0,dp(8),0,dp(8)); root.addView(totalText);
        updateTotal();
        unit.setOnFocusChangeListener((v,f)->{if(!f)updateTotal();});
        qty.setOnFocusChangeListener((v,f)->{if(!f)updateTotal();});

        Button pdf=new Button(this); pdf.setText("PDF TEKLİF OLUŞTUR");
        pdf.setOnClickListener(v->makePdf()); root.addView(pdf);

        Button clear=new Button(this); clear.setText("TEMİZLE");
        clear.setOnClickListener(v->{customer.setText("");product.setText("");qty.setText("1");unit.setText("0");note.setText("");updateTotal();});
        root.addView(clear);

        Button save=new Button(this); save.setText("İŞLETME BİLGİSİNİ KAYDET");
        save.setOnClickListener(v->{prefs.edit().putString("business",business.getText().toString()).apply();
            Toast.makeText(this,"Kaydedildi",Toast.LENGTH_SHORT).show();});
        root.addView(save);

        ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
    }

    EditText field(String hint,String value){
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(16);
        e.setSingleLine(true); e.setPadding(0,0,dp(8),0);
        return e;
    }

    void updateTotal(){
        try{
            double q=Double.parseDouble(qty.getText().toString().replace(",","."));
            double u=Double.parseDouble(unit.getText().toString().replace(",",".")); 
            totalText.setText(String.format(Locale.US,"Toplam: %,.2f ₺",q*u).replace(",", "X").replace(".", ",").replace("X","."));
        }catch(Exception e){ totalText.setText("Toplam: 0,00 ₺"); }
    }

    void makePdf(){
        try{
            prefs.edit().putString("business",business.getText().toString()).apply();
            double q=Double.parseDouble(qty.getText().toString().replace(",","."));
            double u=Double.parseDouble(unit.getText().toString().replace(",","."));
            double total=q*u;
            PdfDocument doc=new PdfDocument();
            PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
            Canvas c=page.getCanvas(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.rgb(23,105,170)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(26);
            c.drawText("HIZLI TEKLİF",40,60,p);
            p.setColor(Color.DKGRAY); p.setTypeface(Typeface.DEFAULT); p.setTextSize(13);
            c.drawText("Tarih: "+new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date()),40,88,p);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(17); c.drawText(business.getText().toString(),40,125,p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(15);
            c.drawText("Müşteri: "+customer.getText().toString(),40,155,p);
            c.drawText("Ürün/Hizmet: "+product.getText().toString(),40,190,p);
            c.drawText("Miktar: "+qty.getText()+"    Birim: "+unit.getText()+" ₺",40,225,p);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22); c.drawText(String.format(Locale.US,"TOPLAM: %.2f ₺",total),40,275,p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(14);
            c.drawText("Not: "+note.getText().toString(),40,320,p);
            p.setTextSize(11); c.drawText("Bu belge bilgilendirme/teklif amaçlıdır.",40,790,p);
            doc.finishPage(page);
            File dir=new File(getExternalFilesDir(null),"Teklifler"); if(!dir.exists())dir.mkdirs();
            File f=new File(dir,"Teklif_"+System.currentTimeMillis()+".pdf");
            FileOutputStream out=new FileOutputStream(f); doc.writeTo(out); out.close(); doc.close();
            Intent share=new Intent(Intent.ACTION_SEND); share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            // FileProvider is avoided: save and open via ACTION_VIEW where supported.
            Intent view=new Intent(Intent.ACTION_VIEW); view.setDataAndType(Uri.fromFile(f),"application/pdf");
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try{startActivity(view);}catch(Exception ex){
                Toast.makeText(this,"PDF oluşturuldu: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show();
            }
        }catch(Exception e){ Toast.makeText(this,"PDF oluşturulamadı: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
}
